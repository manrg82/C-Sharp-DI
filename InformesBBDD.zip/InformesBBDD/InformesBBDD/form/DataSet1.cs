﻿namespace InformesBBDD.form
{
}

namespace InformesBBDD.form {
    
    
    public partial class DataSet1 {
    }
}
namespace InformesBBDD.form {
    
    
    public partial class DataSet1 {
    }
}
