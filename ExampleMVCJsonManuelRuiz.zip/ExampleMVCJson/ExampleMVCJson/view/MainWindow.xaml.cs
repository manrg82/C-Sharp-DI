﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExampleMVCJson.controller;
using ExampleMVCJson.model;

namespace ExampleMVCJson
{
    public partial class MainWindow : Window
    {
        private readonly PersonaController _controller;
        private Persona? _selectedPersona;

        public MainWindow()
        {
            InitializeComponent();
            _controller = new PersonaController();
            LoadData();
        }

        private void LoadData()
        {
            dataGridUsers.ItemsSource = null;
            dataGridUsers.ItemsSource = _controller.GetAll();
        }

        private void BtnNew_Click(object sender, RoutedEventArgs e)
        {
            _selectedPersona = null;
            txtName.Text = string.Empty;
            txtAge.Text = string.Empty;
            txtName.Focus();
        }

        private void BtnDel_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedPersona != null)
            {
                _controller.Delete(_selectedPersona.Id);
                _selectedPersona = null;
                txtName.Text = string.Empty;
                txtAge.Text = string.Empty;
                LoadData();
            }
            else
            {
                MessageBox.Show("Please select a person to delete.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Please enter a name.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(txtAge.Text, out int age) || age < 0)
            {
                MessageBox.Show("Please enter a valid age.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (_selectedPersona == null)
            {
                _controller.Add(txtName.Text, age);
            }
            else
            {                
                _selectedPersona.Name = txtName.Text;
                _selectedPersona.Age = age;
                _controller.Update(_selectedPersona);
            }

            _selectedPersona = null;
            txtName.Text = string.Empty;
            txtAge.Text = string.Empty;
            LoadData();
        }

        private void DgvPeople_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dataGridUsers.SelectedItem is Persona persona)
            {
                _selectedPersona = persona;
                txtName.Text = persona.Name;
                txtAge.Text = persona.Age.ToString();
            }
        }
    }
}