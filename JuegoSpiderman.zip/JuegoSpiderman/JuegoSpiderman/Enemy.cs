﻿using System;

public abstract class Enemy : Tile{
	protected int dmg;
	public abstract int GetDmg();
	
}
