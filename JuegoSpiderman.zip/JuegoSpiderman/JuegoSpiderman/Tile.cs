﻿using System;

public abstract class Tile
{
    protected char displayChar;
	public abstract char getDisplayChar();


}
