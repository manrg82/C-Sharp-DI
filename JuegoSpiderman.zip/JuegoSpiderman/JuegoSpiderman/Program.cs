﻿using System;
using JuegoSpiderman;
public class Program
{
    static void Main(string[] args)
    {
        
        Game gm=new Game();
        gm.startGame();
    }
}
