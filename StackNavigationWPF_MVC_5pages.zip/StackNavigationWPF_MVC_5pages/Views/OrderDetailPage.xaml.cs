using System.Windows.Controls;
using StackNavigationWPF.Controllers;

namespace StackNavigationWPF.Views
{
    // P�gina que muestra los detalles de un pedido
    public partial class OrderDetailPage : Page
    {
        public OrderDetailPage()
        {
            InitializeComponent(); // Inicializa la interfaz definida en XAML
        }

        // Evento del bot�n: navega a la p�gina de configuraci�n (Settings)
        private void Next_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            // Llama al controller para navegar a SettingsPage
            NavigationController.Instance.GoSettings();
        }
    }
}