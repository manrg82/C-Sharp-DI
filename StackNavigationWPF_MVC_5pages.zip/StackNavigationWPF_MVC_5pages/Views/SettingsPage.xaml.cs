using System.Windows.Controls;

namespace StackNavigationWPF.Views
{
    public partial class SettingsPage : Page
    {
        public SettingsPage()
        {
            InitializeComponent(); // Fin del stack
        }
    }
}