using System.Windows.Controls;
using StackNavigationWPF.Controllers;

namespace StackNavigationWPF.Views
{
    // P�gina que representa la secci�n de pedidos
    public partial class OrdersPage : Page
    {
        public OrdersPage()
        {
            InitializeComponent(); // Inicializa la interfaz definida en XAML
        }

        // Evento del bot�n: navega a la p�gina de detalle de un pedido
        private void Next_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            // Llama al controller para navegar a OrderDetailPage
            NavigationController.Instance.GoOrderDetail();
        }
    }
}