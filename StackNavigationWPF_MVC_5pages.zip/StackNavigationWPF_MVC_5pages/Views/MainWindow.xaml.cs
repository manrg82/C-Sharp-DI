using System.Windows;
using StackNavigationWPF.Controllers;

namespace StackNavigationWPF.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Inicializa el controller pas�ndole el Frame donde navegar�
            NavigationController.Initialize(MainFrame);

            // Comienza la navegaci�n desde la HomePage
            NavigationController.Instance.GoHome();
        }
    }
}