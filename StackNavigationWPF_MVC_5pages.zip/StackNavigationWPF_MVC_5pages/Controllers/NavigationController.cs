using System.Windows.Controls;
using StackNavigationWPF.Views;

namespace StackNavigationWPF.Controllers
{
    // Controller centralizado para la navegaci�n
    // Se encarga de manejar el Frame y decidir qu� p�gina mostrar
    public class NavigationController
    {
        private static NavigationController instance; // Singleton
        private readonly Frame frame; // Frame de la ventana principal donde se muestran las p�ginas

        // Constructor privado: inicializa con un Frame
        private NavigationController(Frame frame)
        {
            this.frame = frame;
        }

        // Inicializa la instancia �nica del controller
        public static void Initialize(Frame frame)
        {
            instance = new NavigationController(frame);
        }

        // Acceso global a la instancia del controller
        public static NavigationController Instance => instance;

        // M�todos para navegar a cada p�gina
        // Cada Navigate agrega una p�gina a la pila de navegaci�n interna de WPF
        public void GoHome() => frame.Navigate(new HomePage());
        public void GoCustomers() => frame.Navigate(new CustomersPage());
        public void GoOrders() => frame.Navigate(new OrdersPage());
        public void GoOrderDetail() => frame.Navigate(new OrderDetailPage());
        public void GoSettings() => frame.Navigate(new SettingsPage());
    }
}