﻿using ApiSerializarDeserializar.domain;
using ApiSerializarDeserializar.persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ApiSerializarDeserializar
{
    public partial class MainWindow : Window
    {
        ApiService _servicio = new ApiService();
        private List<Post> listaCompleta = new List<Post>();

        public MainWindow()
        {
            InitializeComponent();
            // Eventos de búsqueda en tiempo real
            txtBuscar.TextChanged += TxtBuscar_TextChanged;
            txtFiltroId.TextChanged += TxtFiltroId_TextChanged;
        }

        // Trae todos los Pokémon de la API
        private async void BtnTraer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var lista = await _servicio.TraerTodos();
                
                if (lista != null && lista.Count > 0)
                {
                    listaCompleta = new List<Post>(lista);
                    ActualizarLista(listaCompleta);
                    txtEstado.Text = $"Estado: Se cargaron {lista.Count} Pokémon de la API";
                }
                else
                {
                    MessageBox.Show("No se pudieron cargar los Pokémon.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    txtEstado.Text = "Estado: Error al cargar Pokémon";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al conectar con la API: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                txtEstado.Text = "Estado: Error de conexión";
            }
        }

        // Guarda los Pokémon en disco
        private void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var lista = listaVisual.ItemsSource as List<Post>;
                
                if (lista == null || lista.Count == 0)
                {
                    MessageBox.Show("Primero debes cargar los Pokémon con el botón 'Traer Todos'", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                
                _servicio.GuardarTodosEnDisco(listaCompleta);
                txtEstado.Text = $"Estado: Se guardaron {listaCompleta.Count} Pokémon en disco";
                MessageBox.Show($"Se guardaron {listaCompleta.Count} Pokémon en disco", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
                txtEstado.Text = "Estado: Error al guardar";
            }
        }

        // Lee los Pokémon guardados en disco
        private void BtnLeer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var lista = _servicio.LeerTodosDelDisco();
                
                if (lista != null && lista.Count > 0)
                {
                    listaCompleta = new List<Post>(lista);
                    ActualizarLista(listaCompleta);
                    txtEstado.Text = $"Estado: Se cargaron {lista.Count} Pokémon del archivo";
                    MessageBox.Show($"Se cargaron {lista.Count} Pokémon del archivo", "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("No hay Pokémon guardados en el archivo.", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                    txtEstado.Text = "Estado: No hay Pokémon en disco";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al leer archivo: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                txtEstado.Text = "Estado: Error al leer";
            }
        }

        // Elimina el Pokémon seleccionado
        private void BtnEliminar_Click(object sender, RoutedEventArgs e)
        {
            var listaActual = listaVisual.ItemsSource as List<Post>;
            var pokemonSeleccionado = listaVisual.SelectedItem as Post;

            if (pokemonSeleccionado == null)
            {
                MessageBox.Show("Debes seleccionar un Pokémon de la lista para eliminarlo.", "Información", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var resultado = MessageBox.Show($"¿Estás seguro de que deseas eliminar a:\n\n'{pokemonSeleccionado.Titulo}'?", "Confirmación", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                listaCompleta.Remove(pokemonSeleccionado);
                ActualizarLista(listaCompleta);
                txtEstado.Text = $"Estado: Pokémon eliminado. Quedan {listaCompleta.Count} Pokémon";
                LimpiarDetalles();
            }
        }

        // Muestra los detalles cuando seleccionas un Pokémon
        private void ListaVisual_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var pokemonSeleccionado = listaVisual.SelectedItem as Post;

            if (pokemonSeleccionado == null)
            {
                LimpiarDetalles();
                return;
            }

            txtDetalleId.Text = pokemonSeleccionado.Id.ToString();
            txtDetalleNombre.Text = pokemonSeleccionado.Titulo;
            txtDetalleAltura.Text = pokemonSeleccionado.UserId.ToString();
            txtDetallePeso.Text = pokemonSeleccionado.Cuerpo.ToString();
        }

        // Busca por nombre en tiempo real
        private void TxtBuscar_TextChanged(object sender, TextChangedEventArgs e)
        {
            AplicarFiltros();
        }

        // Filtra por ID en tiempo real
        private void TxtFiltroId_TextChanged(object sender, TextChangedEventArgs e)
        {
            AplicarFiltros();
        }

        // Aplica los filtros de búsqueda y ID
        private void AplicarFiltros()
        {
            string buscar = txtBuscar.Text.ToLower();
            string filtroId = txtFiltroId.Text;
            
            var listaFiltrada = listaCompleta.ToList();

            // Filtrar por nombre si hay algo escrito
            if (!string.IsNullOrWhiteSpace(buscar))
            {
                listaFiltrada = listaFiltrada
                    .Where(p => p.Titulo.ToLower().Contains(buscar))
                    .ToList();
            }

            // Filtrar por ID si hay algo escrito
            if (!string.IsNullOrWhiteSpace(filtroId))
            {
                if (int.TryParse(filtroId, out int id))
                {
                    listaFiltrada = listaFiltrada
                        .Where(p => p.Id == id)
                        .ToList();
                }
            }

            ActualizarLista(listaFiltrada);
            
            // Mostrar cantidad de resultados
            if (listaFiltrada.Count == 0 && (listaCompleta.Count > 0))
            {
                txtEstado.Text = "Estado: No se encontraron resultados";
            }
            else if (listaFiltrada.Count > 0)
            {
                txtEstado.Text = $"Estado: Mostrando {listaFiltrada.Count} de {listaCompleta.Count} Pokémon";
            }
        }

        // Limpia los filtros de búsqueda
        private void BtnLimpiarFiltros_Click(object sender, RoutedEventArgs e)
        {
            txtBuscar.Text = "";
            txtFiltroId.Text = "";
            ActualizarLista(listaCompleta);
            LimpiarDetalles();
            txtEstado.Text = $"Estado: Mostrando {listaCompleta.Count} Pokémon";
        }

        // Actualiza la lista visual
        private void ActualizarLista(List<Post> lista)
        {
            listaVisual.ItemsSource = null;
            listaVisual.ItemsSource = new List<Post>(lista);
        }

        // Limpia los detalles
        private void LimpiarDetalles()
        {
            txtDetalleId.Text = "---";
            txtDetalleNombre.Text = "---";
            txtDetalleAltura.Text = "---";
            txtDetallePeso.Text = "---";
        }
    }
}
