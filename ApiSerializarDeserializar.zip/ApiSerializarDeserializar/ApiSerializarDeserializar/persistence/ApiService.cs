﻿using ApiSerializarDeserializar.domain;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace ApiSerializarDeserializar.persistence
{
    public class ApiService
    {
        private readonly HttpClient _internet = new HttpClient();
        private const string Url = "https://pokeapi.co/api/v2/pokemon";

        // Trae los 151 Pokémon de la primera generación
        public async Task<List<Post>> TraerTodos()
        {
            List<Post> todosPokemon = new List<Post>();

            try
            {
                for (int i = 1; i <= 151; i++)
                {
                    string json = await _internet.GetStringAsync($"{Url}/{i}");
                    var pokemon = JsonConvert.DeserializeObject<Post>(json);
                    todosPokemon.Add(pokemon);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al traer los Pokémon: " + ex.Message);
            }

            return todosPokemon;
        }

        // Guarda la lista en el archivo datos.json
        public void GuardarTodosEnDisco(List<Post> posts)
        {
            if (posts == null || posts.Count == 0)
            {
                throw new ArgumentException("La lista de Pokémon no puede estar vacía.");
            }
            
            string json = JsonConvert.SerializeObject(posts, Formatting.Indented);
            File.WriteAllText("datos.json", json);
        }

        // Lee la lista desde el archivo datos.json
        public List<Post> LeerTodosDelDisco()
        {
            if (!File.Exists("datos.json")) return null;
            
            string json = File.ReadAllText("datos.json");
            if (string.IsNullOrWhiteSpace(json)) return null;
            
            return JsonConvert.DeserializeObject<List<Post>>(json);
        }
    }
}
