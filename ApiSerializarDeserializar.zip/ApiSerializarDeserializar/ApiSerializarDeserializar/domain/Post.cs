﻿using Newtonsoft.Json;

namespace ApiSerializarDeserializar.domain
{
    public class Post
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("name")]
        public string Titulo { get; set; }

        [JsonProperty("height")]
        public int UserId { get; set; }

        [JsonProperty("weight")]
        public int Cuerpo { get; set; }
    }
}
