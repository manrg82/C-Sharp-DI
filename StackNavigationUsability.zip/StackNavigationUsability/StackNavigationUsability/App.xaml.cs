
using System.Windows;

namespace StackNavigationUsability
{
    public partial class App : Application { }
}
